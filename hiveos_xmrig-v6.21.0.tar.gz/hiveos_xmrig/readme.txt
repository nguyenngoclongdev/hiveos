hiveos_xmrig is HiveOS custom CPU miner package based on https://github.com/nguyenngoclongdev/xmrig
fork of xmrig that allows auto switching to the most profitable CPU algo

List of supported algos:

    rx/0
    rx/wow
    rx/arq
    panthera
    cn-heavy/xhv
    cn-pico/trtl
    cn/half
    cn/gpu
    cn/r
    cn/0
    cn/rwz
    argon2/chukwav2
    astrobwt
